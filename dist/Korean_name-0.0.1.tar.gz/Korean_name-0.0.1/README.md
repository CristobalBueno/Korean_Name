
# Basic example of packages

Introduction:
> Basic example of a python script, where according to the date of birth entered in (dd / mm / yy) format, you get the name in Korean.

Code Samples:
> Some examples of what the program does, entering the data by console and what it shows in its output.
>>Examples:
>First:

>> Input: 01/06/91

>> Output : Hwa Sang Kim

> Second:

>> Input: 15/10/90

> >Output : Soo Eun Park